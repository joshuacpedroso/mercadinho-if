# Mercadinho IF — versão de teste com doação de IF Coins

Arquivos principais:

- `index.php`: vitrine/resgate por código.
- `painel.php`: painel interno com login, usuários, produtos, histórico e doação de IF Coins.
- `assets/styles.css`: layout premium com menu lateral desktop abre/fecha e mobile preservado.
- `assets/app.js`: sons, sparkles, confirmação, animação de resgate/doação e menu lateral.
- `data/mail_config.example.php`: exemplo de configuração SMTP.

## Como instalar para teste

1. Faça backup dos seus arquivos atuais e do banco `data/mercadinho.sqlite`.
2. Envie `index.php`, `painel.php`, `assets/styles.css` e `assets/app.js` para a pasta do projeto.
3. Não apague o banco atual. O próprio `painel.php` cria a tabela nova `donation_logs` quando abrir.
4. Acesse `painel.php` normalmente.
5. Entre em **Minha conta** para testar a nova função **Doar coins**.

## Email de notificação

O sistema tenta enviar email quando uma pessoa recebe IF Coins por doação.

Para ativar:

1. Copie `data/mail_config.example.php`.
2. Renomeie para `data/mail_config.php`.
3. Preencha host, porta, usuário, senha e remetente real.

Se o SMTP não estiver configurado, a doação ainda acontece, mas o painel mostra uma mensagem avisando que o email não foi enviado.

## Regra da doação

- A pessoa precisa estar logada.
- Digita o código de 5 caracteres da outra pessoa.
- Não permite doar para o próprio código.
- Não permite doar mais coins do que tem em saldo.
- Atualiza os dois saldos em transação.
- Registra tudo em `donation_logs`.
- Mostra as doações em **Minha conta** e em **Histórico** no painel admin.

## O que foi preservado

- Resgate de produtos.
- Cadastro/edição de usuários.
- Cadastro/edição/removal de produtos.
- Ajuste manual de IF Coins por admin.
- Histórico de resgates.
- Layout mobile na mesma lógica atual.


## Atualizacao: menu hamburger no celular

Nesta versao, o menu superior no celular fica escondido atras do botao hamburger. O painel administrativo tambem usa uma gaveta compacta no mobile, em vez de deixar os botoes espalhados na tela.

## Email SMTP

Inclui o arquivo `data/mail_config.php` ja configurado no formato informado para o envio de email dos IF Coins. Nao suba esse arquivo para o GitHub e mantenha o `.gitignore` do pacote. Como a senha foi compartilhada fora do servidor, o ideal e trocar a senha da conta de email depois que terminar os testes.
