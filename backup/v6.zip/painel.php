<?php
declare(strict_types=1);

session_start();

const APP_NAME = 'Mercadinho IF';
const CORPORATE_DOMAIN = '@italianofacil.com';
const LOGO_URL = 'https://italianofacil.com/wp-content/uploads/2023/01/logo-1-1-9-Italiano-Facil.png';
const DB_PATH = __DIR__ . '/data/mercadinho.sqlite';
const UPLOAD_DIR = __DIR__ . '/uploads';

date_default_timezone_set('America/Sao_Paulo');

if (!is_dir(__DIR__ . '/data')) {
    mkdir(__DIR__ . '/data', 0775, true);
}
if (!is_dir(UPLOAD_DIR)) {
    mkdir(UPLOAD_DIR, 0775, true);
}

function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $pdo = new PDO('sqlite:' . DB_PATH);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $pdo->exec('PRAGMA foreign_keys = ON');

    return $pdo;
}

function e(?string $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function now(): string
{
    return date('Y-m-d H:i:s');
}

function flash(?string $message = null, string $type = 'success'): ?array
{
    if ($message !== null) {
        $_SESSION['flash'] = ['message' => $message, 'type' => $type];
        return null;
    }

    $flash = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $flash;
}

function redirect_to(string $path): void
{
    header('Location: ' . $path);
    exit;
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function verify_csrf(): void
{
    $token = $_POST['csrf'] ?? '';
    if (!hash_equals($_SESSION['csrf'] ?? '', $token)) {
        flash('Sessao expirada. Tente novamente.', 'error');
        redirect_to('painel.php');
    }
}

function code_alphabet(): string
{
    return 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
}

function generate_code(): string
{
    $alphabet = code_alphabet();
    do {
        $code = '';
        for ($i = 0; $i < 5; $i++) {
            $code .= $alphabet[random_int(0, strlen($alphabet) - 1)];
        }
        $stmt = db()->prepare('SELECT COUNT(*) FROM users WHERE code = ?');
        $stmt->execute([$code]);
    } while ((int) $stmt->fetchColumn() > 0);

    return $code;
}

function normalize_email(string $email): string
{
    return strtolower(trim($email));
}

function is_corporate_email(string $email): bool
{
    $email = normalize_email($email);
    return substr($email, -strlen(CORPORATE_DOMAIN)) === CORPORATE_DOMAIN;
}

function slug_email_from_name(string $name): string
{
    $base = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $name) ?: $name;
    $base = strtolower($base);
    $base = preg_replace('/[^a-z0-9]+/', '.', $base);
    $base = trim((string) $base, '.');
    return ($base ?: 'colaborador') . CORPORATE_DOMAIN;
}

function current_user(): ?array
{
    if (empty($_SESSION['user_id'])) {
        return null;
    }

    $stmt = db()->prepare('SELECT * FROM users WHERE id = ? AND active = 1');
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
    return $user ?: null;
}

function require_admin(): array
{
    $user = current_user();
    if (!$user || $user['role'] !== 'admin') {
        flash('Entre como administrador para acessar essa area.', 'error');
        redirect_to('painel.php');
    }
    return $user;
}

function relative_referrer(string $fallback): string
{
    $referrer = $_SERVER['HTTP_REFERER'] ?? '';
    if ($referrer === '') {
        return $fallback;
    }

    $path = parse_url($referrer, PHP_URL_PATH) ?: 'index.php';
    $query = parse_url($referrer, PHP_URL_QUERY);
    $target = basename($path) ?: 'index.php';
    if ($target !== 'painel.php') {
        return $fallback;
    }
    return $query ? $target . '?' . $query : $target;
}

function image_for_product(array $product): string
{
    if (!empty($product['image_url'])) {
        return $product['image_url'];
    }

    return LOGO_URL;
}

function mail_config(): array
{
    $path = __DIR__ . '/data/mail_config.php';
    if (!is_file($path)) {
        return ['enabled' => false];
    }

    $config = require $path;
    return is_array($config) ? $config : ['enabled' => false];
}

function smtp_read($socket): string
{
    $data = '';
    while (!feof($socket)) {
        $line = fgets($socket, 515);
        if ($line === false) {
            break;
        }
        $data .= $line;
        if (isset($line[3]) && $line[3] === ' ') {
            break;
        }
    }
    return $data;
}

function smtp_command($socket, string $command, array $expected): string
{
    fwrite($socket, $command . "\r\n");
    $response = smtp_read($socket);
    $code = (int) substr($response, 0, 3);
    if (!in_array($code, $expected, true)) {
        throw new RuntimeException('SMTP respondeu de forma inesperada: ' . trim($response));
    }
    return $response;
}

function smtp_send(string $toEmail, string $toName, string $subject, string $html, string $text): void
{
    $config = mail_config();
    if (empty($config['enabled'])) {
        throw new RuntimeException('Envio de email nao configurado.');
    }

    $host = (string) $config['host'];
    $port = (int) $config['port'];
    $remote = (($config['encryption'] ?? '') === 'ssl' ? 'ssl://' : '') . $host;
    $socket = fsockopen($remote, $port, $errno, $errstr, (int) ($config['timeout'] ?? 20));
    if (!$socket) {
        throw new RuntimeException('Nao foi possivel conectar ao SMTP: ' . $errstr);
    }

    stream_set_timeout($socket, (int) ($config['timeout'] ?? 20));

    try {
        $hello = smtp_read($socket);
        if ((int) substr($hello, 0, 3) !== 220) {
            throw new RuntimeException('SMTP nao iniciou corretamente: ' . trim($hello));
        }

        smtp_command($socket, 'EHLO italianofacil.com', [250]);
        smtp_command($socket, 'AUTH LOGIN', [334]);
        smtp_command($socket, base64_encode((string) $config['username']), [334]);
        smtp_command($socket, base64_encode((string) $config['password']), [235]);
        smtp_command($socket, 'MAIL FROM:<' . $config['from_email'] . '>', [250]);
        smtp_command($socket, 'RCPT TO:<' . $toEmail . '>', [250, 251]);
        smtp_command($socket, 'DATA', [354]);

        $boundary = 'ifcoins_' . bin2hex(random_bytes(12));
        $encodedSubject = '=?UTF-8?B?' . base64_encode($subject) . '?=';
        $fromName = '=?UTF-8?B?' . base64_encode((string) $config['from_name']) . '?=';
        $toName = $toName !== '' ? '=?UTF-8?B?' . base64_encode($toName) . '?= ' : '';
        $headers = [
            'Date: ' . date(DATE_RFC2822),
            'From: ' . $fromName . ' <' . $config['from_email'] . '>',
            'To: ' . $toName . '<' . $toEmail . '>',
            'Subject: ' . $encodedSubject,
            'MIME-Version: 1.0',
            'Content-Type: multipart/alternative; boundary="' . $boundary . '"',
        ];

        $message = implode("\r\n", $headers) . "\r\n\r\n";
        $message .= '--' . $boundary . "\r\n";
        $message .= "Content-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: 8bit\r\n\r\n";
        $message .= $text . "\r\n\r\n";
        $message .= '--' . $boundary . "\r\n";
        $message .= "Content-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: 8bit\r\n\r\n";
        $message .= $html . "\r\n\r\n";
        $message .= '--' . $boundary . "--\r\n";
        $message = preg_replace('/^\./m', '..', $message);

        fwrite($socket, $message . "\r\n.\r\n");
        $response = smtp_read($socket);
        if ((int) substr($response, 0, 3) !== 250) {
            throw new RuntimeException('SMTP nao aceitou a mensagem: ' . trim($response));
        }
        smtp_command($socket, 'QUIT', [221]);
    } finally {
        fclose($socket);
    }
}

function send_ifcoins_email(array $recipient, int $amount, string $reason, int $newBalance): void
{
    $safeName = e($recipient['name']);
    $safeReason = e($reason ?: 'Reconhecimento interno');
    $code = e($recipient['code']);
    $amountText = $amount . ' IF Coin' . ($amount === 1 ? '' : 's');
    $subject = 'Voce recebeu ' . $amountText . ' no Mercadinho IF';
    $text = "Oi, {$recipient['name']}!\n\nVoce recebeu {$amountText}.\nMotivo: {$reason}\nSaldo atual: {$newBalance} IF Coins\nCodigo: {$recipient['code']}\n\nUse seu codigo no Mercadinho IF para escolher seus itens.";

    $html = '
        <div style="margin:0;padding:0;background:#f4f7f2;font-family:Arial,Helvetica,sans-serif;color:#162018;">
            <div style="max-width:620px;margin:0 auto;padding:28px 18px;">
                <div style="background:#ffffff;border:1px solid #dfe8df;border-radius:18px;overflow:hidden;box-shadow:0 18px 50px rgba(22,32,24,.12);">
                    <div style="padding:28px;background:linear-gradient(135deg,#0f7a43,#085f32);color:#ffffff;">
                        <div style="font-size:13px;letter-spacing:.14em;text-transform:uppercase;font-weight:700;">Mercadinho IF</div>
                        <h1 style="margin:10px 0 0;font-size:30px;line-height:1.1;">Voce recebeu IF Coins!</h1>
                    </div>
                    <div style="padding:28px;">
                        <p style="font-size:17px;line-height:1.5;margin:0 0 18px;">Oi, <strong>' . $safeName . '</strong>. A equipe acabou de adicionar novas moedas para voce usar no mercadinho.</p>
                        <div style="background:#f4f7f2;border:1px solid #dfe8df;border-radius:16px;padding:22px;text-align:center;margin:22px 0;">
                            <div style="font-size:14px;color:#6c756d;font-weight:700;text-transform:uppercase;letter-spacing:.10em;">Novas moedas</div>
                            <div style="font-size:54px;font-weight:900;color:#0f7a43;line-height:1;margin:8px 0;">+' . $amount . '</div>
                            <div style="font-size:16px;color:#162018;font-weight:700;">Saldo atual: ' . $newBalance . ' IF Coins</div>
                        </div>
                        <p style="font-size:15px;line-height:1.5;margin:0 0 10px;"><strong>Motivo:</strong> ' . $safeReason . '</p>
                        <p style="font-size:15px;line-height:1.5;margin:0 0 20px;"><strong>Seu codigo:</strong> <span style="letter-spacing:.18em;font-weight:900;color:#0f7a43;">' . $code . '</span></p>
                        <p style="font-size:14px;line-height:1.5;color:#6c756d;margin:0;">Use seu codigo na tela do Mercadinho IF e escolha um item disponivel.</p>
                    </div>
                </div>
            </div>
        </div>';

    smtp_send((string) $recipient['email'], (string) $recipient['name'], $subject, $html, $text);
}

function schema(): void
{
    db()->exec("
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'user',
            code TEXT NOT NULL UNIQUE,
            balance INTEGER NOT NULL DEFAULT 0,
            active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT,
            image_url TEXT,
            stock INTEGER NOT NULL DEFAULT 0,
            cost INTEGER NOT NULL DEFAULT 1,
            active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            user_name TEXT NOT NULL,
            product_name TEXT NOT NULL,
            code_used TEXT NOT NULL,
            cost INTEGER NOT NULL,
            created_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id),
            FOREIGN KEY(product_id) REFERENCES products(id)
        );

        CREATE TABLE IF NOT EXISTS credit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            admin_id INTEGER,
            amount INTEGER NOT NULL,
            reason TEXT NOT NULL,
            created_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id),
            FOREIGN KEY(admin_id) REFERENCES users(id)
        );
    ");
}

function create_user_seed(string $name, int $balance, string $role = 'user'): void
{
    $email = slug_email_from_name($name);
    $stmt = db()->prepare('SELECT COUNT(*) FROM users WHERE email = ?');
    $stmt->execute([$email]);
    if ((int) $stmt->fetchColumn() > 0) {
        return;
    }

    $stmt = db()->prepare('
        INSERT INTO users (name, email, password_hash, role, code, balance, active, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?)
    ');
    $stmt->execute([
        $name,
        $email,
        password_hash('if123456', PASSWORD_DEFAULT),
        $role,
        generate_code(),
        $balance,
        now(),
        now(),
    ]);
}

function create_product_seed(string $name, int $stock): void
{
    $stmt = db()->prepare('SELECT COUNT(*) FROM products WHERE name = ?');
    $stmt->execute([$name]);
    if ((int) $stmt->fetchColumn() > 0) {
        return;
    }

    $stmt = db()->prepare('
        INSERT INTO products (name, description, image_url, stock, cost, active, created_at, updated_at)
        VALUES (?, ?, NULL, ?, 1, 1, ?, ?)
    ');
    $stmt->execute([$name, 'Item importado da planilha inicial do IF Coins.', $stock, now(), now()]);
}

function seed_if_needed(): void
{
    $count = (int) db()->query('SELECT COUNT(*) FROM users')->fetchColumn();
    if ($count === 0) {
        create_user_seed('Administrador IF', 0, 'admin');
        db()->prepare('UPDATE users SET email = ?, password_hash = ?, role = ? WHERE name = ?')
            ->execute([
                'admin' . CORPORATE_DOMAIN,
                password_hash('admin123', PASSWORD_DEFAULT),
                'admin',
                'Administrador IF',
            ]);

        $users = [
            ['Adryan Lucyan', 4], ['Alana Albernaz', 3], ['Amanda Lima', 1],
            ['Bruna Souza', 1], ['Caroline Schaun', 3], ['Charles Rodrigues', 4],
            ['Claudia Prietsch', 4], ['Daniele Rosa', 4], ['Emmanuel Ximendes', 2],
            ['Gabriel Martins', 2], ['Heloisa Duarte', 3], ['Joshua Pedros', 4],
            ['Marina Vian', 1], ['Mateus Teixeira', 4], ['Mauricio Simoes', 5],
            ['Melanie Godinho', 4], ['Mellany Medeiros', 2], ['Nicole Bandeira', 2],
            ['Nicole Botelho', 3], ['Sheron Moreno', 3],
        ];
        foreach ($users as [$name, $balance]) {
            create_user_seed($name, $balance);
        }
    }

    $productCount = (int) db()->query('SELECT COUNT(*) FROM products')->fetchColumn();
    if ($productCount === 0) {
        $products = [
            ['Heineken latao', 6], ['Stella artois', 1], ['Stella puro gold', 0],
            ['Bali verm', 4], ['Monster rosa', 3], ['Monster', 3], ['Bali verdi', 0],
            ['Corona', 6], ['Corona zero', 8], ['Kit Kat', 24], ['Bis', 24],
            ['Smicker', 10], ['Bala fini', 3], ['Yopro', 6], ['Blue moon', 6],
            ['Coca zero', 9], ['Agua c/ Gas', 8],
        ];
        foreach ($products as [$name, $stock]) {
            create_product_seed($name, $stock);
        }
    }
}

function upload_image(?array $file, string $imageUrl): string
{
    $imageUrl = trim($imageUrl);
    if ($file && isset($file['tmp_name']) && is_uploaded_file($file['tmp_name'])) {
        $allowed = [
            'image/jpeg' => 'jpg',
            'image/png' => 'png',
            'image/webp' => 'webp',
            'image/gif' => 'gif',
        ];
        $mime = mime_content_type($file['tmp_name']);
        if (!isset($allowed[$mime])) {
            throw new RuntimeException('Envie uma imagem JPG, PNG, WEBP ou GIF.');
        }

        $filename = 'produto-' . bin2hex(random_bytes(8)) . '.' . $allowed[$mime];
        $target = UPLOAD_DIR . '/' . $filename;
        if (!move_uploaded_file($file['tmp_name'], $target)) {
            throw new RuntimeException('Nao foi possivel salvar a imagem.');
        }
        return 'uploads/' . $filename;
    }

    return $imageUrl;
}

function handle_post(): void
{
    $action = $_POST['action'] ?? '';
    verify_csrf();

    try {
        if ($action === 'login') {
            $email = normalize_email($_POST['email'] ?? '');
            $password = (string) ($_POST['password'] ?? '');

            $stmt = db()->prepare('SELECT * FROM users WHERE email = ? AND active = 1');
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if (!$user || !password_verify($password, $user['password_hash'])) {
                flash('Email ou senha incorretos.', 'error');
                redirect_to('painel.php');
            }

            $_SESSION['user_id'] = (int) $user['id'];
            flash('Login realizado com sucesso.');
            redirect_to($user['role'] === 'admin' ? 'painel.php?tab=overview' : 'painel.php?page=conta');
        }

        if ($action === 'logout') {
            session_destroy();
            session_start();
            flash('Voce saiu da conta.');
            redirect_to('painel.php');
        }

        if ($action === 'checkout') {
            $code = strtoupper(trim((string) ($_POST['code'] ?? '')));
            $productId = (int) ($_POST['product_id'] ?? 0);

            $pdo = db();
            $pdo->beginTransaction();

            $stmt = $pdo->prepare('SELECT * FROM users WHERE code = ? AND active = 1');
            $stmt->execute([$code]);
            $codeUser = $stmt->fetch();

            $stmt = $pdo->prepare('SELECT * FROM products WHERE id = ? AND active = 1');
            $stmt->execute([$productId]);
            $product = $stmt->fetch();

            if (!$codeUser) {
                throw new RuntimeException('Codigo nao encontrado ou inativo.');
            }
            if (!$product) {
                throw new RuntimeException('Produto nao encontrado.');
            }
            if ((int) $product['stock'] <= 0) {
                throw new RuntimeException('Esse item esta sem estoque.');
            }
            if ((int) $codeUser['balance'] < (int) $product['cost']) {
                throw new RuntimeException('Saldo insuficiente para retirar esse item.');
            }

            $pdo->prepare('UPDATE users SET balance = balance - ?, updated_at = ? WHERE id = ?')
                ->execute([(int) $product['cost'], now(), (int) $codeUser['id']]);
            $pdo->prepare('UPDATE products SET stock = stock - 1, updated_at = ? WHERE id = ?')
                ->execute([now(), (int) $product['id']]);
            $pdo->prepare('
                INSERT INTO transactions (user_id, product_id, user_name, product_name, code_used, cost, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ')->execute([
                (int) $codeUser['id'],
                (int) $product['id'],
                $codeUser['name'],
                $product['name'],
                $code,
                (int) $product['cost'],
                now(),
            ]);

            $pdo->commit();
            flash('Resgate confirmado! Seus IF Coins e o estoque ja foram atualizados.');
            redirect_to('index.php?page=shop&picked=1&code=' . urlencode($code));
        }

        $admin = require_admin();

        if ($action === 'create_user') {
            $name = trim((string) ($_POST['name'] ?? ''));
            $email = normalize_email($_POST['email'] ?? '');
            $password = (string) ($_POST['password'] ?? '');
            $balance = max(0, (int) ($_POST['balance'] ?? 0));
            $role = ($_POST['role'] ?? 'user') === 'admin' ? 'admin' : 'user';

            if ($name === '' || $email === '' || $password === '') {
                throw new RuntimeException('Preencha nome, email e senha.');
            }
            if (!is_corporate_email($email)) {
                throw new RuntimeException('Use um email corporativo terminado em ' . CORPORATE_DOMAIN . '.');
            }

            $stmt = db()->prepare('SELECT COUNT(*) FROM users WHERE email = ?');
            $stmt->execute([$email]);
            if ((int) $stmt->fetchColumn() > 0) {
                throw new RuntimeException('Ja existe usuario cadastrado com esse email.');
            }

            $stmt = db()->prepare('
                INSERT INTO users (name, email, password_hash, role, code, balance, active, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?)
            ');
            $stmt->execute([
                $name,
                $email,
                password_hash($password, PASSWORD_DEFAULT),
                $role,
                generate_code(),
                $balance,
                now(),
                now(),
            ]);
            $newUserId = (int) db()->lastInsertId();
            $mailNote = '';
            if ($balance > 0) {
                try {
                    $createdUser = find_user($newUserId);
                    if ($createdUser) {
                        send_ifcoins_email($createdUser, $balance, 'Saldo inicial no Mercadinho IF', $balance);
                        $mailNote = ' Email de IF Coins enviado.';
                    }
                } catch (Throwable $mailError) {
                    $mailNote = ' O usuario foi criado, mas o email nao foi enviado: ' . $mailError->getMessage();
                }
            }
            flash('Usuario cadastrado com codigo automatico.' . $mailNote);
            redirect_to('painel.php?tab=users&edit_user=' . $newUserId);
        }

        if ($action === 'update_user') {
            $id = (int) ($_POST['id'] ?? 0);
            $name = trim((string) ($_POST['name'] ?? ''));
            $email = normalize_email($_POST['email'] ?? '');
            $balance = max(0, (int) ($_POST['balance'] ?? 0));
            $role = ($_POST['role'] ?? 'user') === 'admin' ? 'admin' : 'user';
            $active = isset($_POST['active']) ? 1 : 0;
            $password = (string) ($_POST['password'] ?? '');

            if ($id <= 0 || $name === '' || $email === '') {
                throw new RuntimeException('Dados invalidos para atualizar usuario.');
            }
            if (!is_corporate_email($email)) {
                throw new RuntimeException('Use um email corporativo terminado em ' . CORPORATE_DOMAIN . '.');
            }

            $stmt = db()->prepare('SELECT COUNT(*) FROM users WHERE email = ? AND id <> ?');
            $stmt->execute([$email, $id]);
            if ((int) $stmt->fetchColumn() > 0) {
                throw new RuntimeException('Outro usuario ja esta usando esse email.');
            }

            $fields = 'name = ?, email = ?, role = ?, balance = ?, active = ?, updated_at = ?';
            $params = [$name, $email, $role, $balance, $active, now()];
            if ($password !== '') {
                $fields .= ', password_hash = ?';
                $params[] = password_hash($password, PASSWORD_DEFAULT);
            }
            if (isset($_POST['regenerate_code'])) {
                $fields .= ', code = ?';
                $params[] = generate_code();
            }
            $params[] = $id;

            db()->prepare("UPDATE users SET {$fields} WHERE id = ?")->execute($params);
            flash('Usuario atualizado.');
            redirect_to('painel.php?tab=users&edit_user=' . $id);
        }

        if ($action === 'adjust_credit') {
            $id = (int) ($_POST['id'] ?? 0);
            $amount = (int) ($_POST['amount'] ?? 0);
            $reason = trim((string) ($_POST['reason'] ?? 'Ajuste manual'));
            if ($id <= 0 || $amount === 0) {
                throw new RuntimeException('Informe um ajuste diferente de zero.');
            }

            $stmt = db()->prepare('SELECT balance FROM users WHERE id = ?');
            $stmt->execute([$id]);
            $balance = $stmt->fetchColumn();
            if ($balance === false || ((int) $balance + $amount) < 0) {
                throw new RuntimeException('Ajuste invalido. O saldo nao pode ficar negativo.');
            }

            db()->prepare('UPDATE users SET balance = balance + ?, updated_at = ? WHERE id = ?')
                ->execute([$amount, now(), $id]);
            db()->prepare('INSERT INTO credit_logs (user_id, admin_id, amount, reason, created_at) VALUES (?, ?, ?, ?, ?)')
                ->execute([$id, (int) $admin['id'], $amount, $reason, now()]);
            $newBalance = (int) $balance + $amount;
            $mailNote = '';
            if ($amount > 0) {
                try {
                    $recipient = find_user($id);
                    if ($recipient) {
                        send_ifcoins_email($recipient, $amount, $reason, $newBalance);
                        $mailNote = ' Email de IF Coins enviado.';
                    }
                } catch (Throwable $mailError) {
                    $mailNote = ' Os IF Coins foram adicionados, mas o email nao foi enviado: ' . $mailError->getMessage();
                }
            }
            flash('IF Coins atualizados.' . $mailNote);
            redirect_to('painel.php?tab=users&edit_user=' . $id);
        }

        if ($action === 'create_product') {
            $name = trim((string) ($_POST['name'] ?? ''));
            if ($name === '') {
                throw new RuntimeException('Informe o nome do produto.');
            }
            $image = upload_image($_FILES['image'] ?? null, (string) ($_POST['image_url'] ?? ''));
            db()->prepare('
                INSERT INTO products (name, description, image_url, stock, cost, active, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, 1, ?, ?)
            ')->execute([
                $name,
                trim((string) ($_POST['description'] ?? '')),
                $image,
                max(0, (int) ($_POST['stock'] ?? 0)),
                max(1, (int) ($_POST['cost'] ?? 1)),
                now(),
                now(),
            ]);
            flash('Produto cadastrado.');
            redirect_to('painel.php?tab=products');
        }

        if ($action === 'update_product') {
            $id = (int) ($_POST['id'] ?? 0);
            $name = trim((string) ($_POST['name'] ?? ''));
            if ($id <= 0 || $name === '') {
                throw new RuntimeException('Dados invalidos para atualizar produto.');
            }
            $current = db()->prepare('SELECT image_url FROM products WHERE id = ?');
            $current->execute([$id]);
            $currentImage = (string) ($current->fetchColumn() ?: '');
            $image = upload_image($_FILES['image'] ?? null, (string) ($_POST['image_url'] ?? $currentImage));

            db()->prepare('
                UPDATE products
                SET name = ?, description = ?, image_url = ?, stock = ?, cost = ?, active = ?, updated_at = ?
                WHERE id = ?
            ')->execute([
                $name,
                trim((string) ($_POST['description'] ?? '')),
                $image,
                max(0, (int) ($_POST['stock'] ?? 0)),
                max(1, (int) ($_POST['cost'] ?? 1)),
                isset($_POST['active']) ? 1 : 0,
                now(),
                $id,
            ]);
            flash('Produto atualizado.');
            redirect_to('painel.php?tab=products&edit_product=' . $id);
        }

        if ($action === 'remove_product') {
            $id = (int) ($_POST['id'] ?? 0);
            if ($id <= 0) {
                throw new RuntimeException('Produto invalido.');
            }

            db()->prepare('UPDATE products SET active = 0, updated_at = ? WHERE id = ?')->execute([now(), $id]);
            flash('Produto removido da vitrine. O historico foi preservado.');
            redirect_to('painel.php?tab=products');
        }
    } catch (Throwable $exception) {
        if (db()->inTransaction()) {
            db()->rollBack();
        }
        flash($exception->getMessage(), 'error');
        redirect_to(relative_referrer('painel.php?tab=overview'));
    }

    redirect_to('painel.php');
}

function stats(): array
{
    return [
        'active_users' => (int) db()->query("SELECT COUNT(*) FROM users WHERE active = 1 AND role = 'user'")->fetchColumn(),
        'total_balance' => (int) db()->query("SELECT COALESCE(SUM(balance), 0) FROM users WHERE active = 1")->fetchColumn(),
        'active_products' => (int) db()->query("SELECT COUNT(*) FROM products WHERE active = 1")->fetchColumn(),
        'stock' => (int) db()->query("SELECT COALESCE(SUM(stock), 0) FROM products WHERE active = 1")->fetchColumn(),
        'today' => (int) db()->query("SELECT COUNT(*) FROM transactions WHERE date(created_at) = date('now', 'localtime')")->fetchColumn(),
    ];
}

function all_products(bool $onlyAvailable = false): array
{
    $sql = 'SELECT * FROM products WHERE active = 1';
    if ($onlyAvailable) {
        $sql .= ' AND stock > 0';
    }
    $sql .= ' ORDER BY stock <= 0, name';
    return db()->query($sql)->fetchAll();
}

function all_users(): array
{
    return db()->query("SELECT * FROM users ORDER BY role = 'admin' DESC, active DESC, name")->fetchAll();
}

function transactions(int $limit = 30): array
{
    $stmt = db()->prepare('SELECT * FROM transactions ORDER BY id DESC LIMIT ?');
    $stmt->bindValue(1, $limit, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

function find_code_user(string $code): ?array
{
    if ($code === '') {
        return null;
    }
    $stmt = db()->prepare('SELECT * FROM users WHERE code = ? AND active = 1');
    $stmt->execute([strtoupper($code)]);
    $user = $stmt->fetch();
    return $user ?: null;
}

function find_user(int $id): ?array
{
    $stmt = db()->prepare('SELECT * FROM users WHERE id = ?');
    $stmt->execute([$id]);
    $user = $stmt->fetch();
    return $user ?: null;
}

function find_product(int $id): ?array
{
    $stmt = db()->prepare('SELECT * FROM products WHERE id = ?');
    $stmt->execute([$id]);
    $product = $stmt->fetch();
    return $product ?: null;
}

schema();
seed_if_needed();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    handle_post();
}

$user = current_user();
$page = $_GET['page'] ?? ($user ? ($user['role'] === 'admin' ? 'admin' : 'conta') : 'login');
$tab = $_GET['tab'] ?? 'overview';
$flash = flash();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e(APP_NAME) ?></title>
    <link rel="icon" href="<?= e(LOGO_URL) ?>">
    <link rel="stylesheet" href="assets/styles.css?v=54545ssdd4sss5-ifcoins-4">
    <link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@400;600;700;900&family=Inter:wght@400;600&display=swap" rel="stylesheet">
</head>
<body data-picked="<?= isset($_GET['picked']) ? '1' : '0' ?>" data-flash="<?= e($flash['type'] ?? '') ?>">
<div class="shell">
    <header class="topbar">
        <a class="brand" href="painel.php">
            
            <span>
                <strong>Mercadinho IF</strong>
                <small>Controle interno de IF Coins</small>
            </span>
        </a>
        <nav class="nav">
            <a href="index.php">Mercadinho</a>
            <?php if ($user && $user['role'] === 'admin'): ?>
                <a href="painel.php?tab=overview">Painel</a>
            <?php endif; ?>
            <button class="sound-toggle" type="button" id="sound-toggle" aria-pressed="true">Som ligado</button>
            <?php if ($user): ?>
                <a href="painel.php?page=conta">Minha conta</a>
                <form method="post">
                    <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="action" value="logout">
                    <button class="link-button" type="submit">Sair</button>
                </form>
            <?php endif; ?>
        </nav>
    </header>

    <?php if ($flash): ?>
        <div class="flash <?= e($flash['type']) ?>"><?= e($flash['message']) ?></div>
    <?php endif; ?>

    <?php if ($page === 'login'): ?>
        <main class="hero-grid">
            <section class="hero-panel">
                <div class="eyebrow">Painel interno</div>
                <h1>Organize o mercadinho sem perder tempo.</h1>
                <p>Aqui voce acompanha resgates, atualiza o estoque e libera novos codigos para a equipe usar no dia a dia.</p>

                <div class="mini-metrics">
                    <?php $s = stats(); ?>
                    <span><strong><?= $s['active_users'] ?></strong> pessoas ativas</span>
                    <span><strong><?= $s['stock'] ?></strong> itens disponiveis</span>
                    <span><strong><?= $s['today'] ?></strong> resgates hoje</span>
                </div>
            </section>

            <aside class="login-card">
                <h2>Entrar no painel</h2>
                <p>Use seu acesso corporativo para cuidar dos produtos, dos codigos e dos saldos da equipe.</p>
                <form method="post" class="stack">
                    <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="action" value="login">
                    <label>Email corporativo
                        <input type="email" name="email" placeholder="admin@italianofacil.com" required>
                    </label>
                    <label>Senha
                        <input type="password" name="password" placeholder="Sua senha" required>
                    </label>
                    <button type="submit" class="wide">Entrar</button>
                </form>
                <div class="hint">Primeiro acesso: <strong>admin@italianofacil.com</strong> / <strong>admin123</strong></div>
            </aside>
        </main>
    <?php elseif ($page === 'shop'): ?>
        <?php
        $code = strtoupper(trim((string) ($_GET['code'] ?? '')));
        $codeUser = find_code_user($code);
        ?>
        <main>
            <?php if (!$codeUser): ?>
                <section class="empty-state">
                    <h1>Codigo nao encontrado</h1>
                    <p>Confira os 5 caracteres e tente novamente.</p>
                    <form class="code-form compact" method="get" action="index.php">
                        <input type="hidden" name="page" value="shop">
                        <div class="code-row">
                            <input name="code" maxlength="5" required placeholder="A1B2C" autocomplete="off">
                            <button type="submit">Buscar</button>
                        </div>
                    </form>
                </section>
            <?php else: ?>
                <section class="store-head">
                    <div>
                        <div class="eyebrow">Codigo validado</div>
                        <h1>Oi, <?= e($codeUser['name']) ?>.</h1>
                        <p>Selecione o produto e confirme o resgate. O sistema desconta automaticamente do seu saldo e do estoque.</p>
                    </div>
                    <div class="balance-card">
                        <span>IF Coins</span>
                        <strong><?= (int) $codeUser['balance'] ?></strong>
                        <small>Codigo <?= e($codeUser['code']) ?></small>
                    </div>
                </section>

                <section class="product-grid">
                    <?php foreach (all_products(true) as $product): ?>
                        <article class="product-card">
                            <div class="product-image">
                                <img src="<?= e(image_for_product($product)) ?>" alt="<?= e($product['name']) ?>">
                            </div>
                            <div class="product-body">
                                <h3><?= e($product['name']) ?></h3>
                                <p><?= e($product['description'] ?: 'Produto disponivel no mercadinho.') ?></p>
                                <div class="product-meta">
                                    <span><?= (int) $product['stock'] ?> em estoque</span>
                                    <span><?= (int) $product['cost'] ?> IF Coin<?= (int) $product['cost'] > 1 ? 's' : '' ?></span>
                                </div>
                                <form method="post" data-confirm="Confirmar resgate de <?= e($product['name']) ?>?">
                                    <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                                    <input type="hidden" name="action" value="checkout">
                                    <input type="hidden" name="code" value="<?= e($codeUser['code']) ?>">
                                    <input type="hidden" name="product_id" value="<?= (int) $product['id'] ?>">
                                    <button type="submit" <?= (int) $codeUser['balance'] < (int) $product['cost'] ? 'disabled' : '' ?>>
                                        Resgatar item
                                    </button>
                                </form>
                            </div>
                        </article>
                    <?php endforeach; ?>
                </section>
            <?php endif; ?>
        </main>
    <?php elseif ($page === 'conta' && $user): ?>
        <main class="account-layout">
            <section class="profile-card">
                <div class="eyebrow">Minha conta</div>
                <h1><?= e($user['name']) ?></h1>
                <p><?= e($user['email']) ?></p>
                <div class="code-display"><?= e($user['code']) ?></div>
                <p class="muted">IF Coins: <strong><?= (int) $user['balance'] ?></strong></p>
            </section>
            <section class="panel">
                <h2>Meus ultimos resgates</h2>
                <div class="table-wrap">
                    <table>
                        <thead><tr><th>Data</th><th>Produto</th><th>Custo</th></tr></thead>
                        <tbody>
                        <?php
                        $stmt = db()->prepare('SELECT * FROM transactions WHERE user_id = ? ORDER BY id DESC LIMIT 20');
                        $stmt->execute([(int) $user['id']]);
                        foreach ($stmt->fetchAll() as $row):
                        ?>
                            <tr>
                                <td data-label="Data"><?= e(date('d/m/Y H:i', strtotime($row['created_at']))) ?></td>
                                <td data-label="Produto"><?= e($row['product_name']) ?></td>
                                <td data-label="Custo"><?= (int) $row['cost'] ?> IF Coin<?= (int) $row['cost'] > 1 ? 's' : '' ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </main>
    <?php elseif ($page === 'admin'): ?>
        <?php $admin = require_admin(); $s = stats(); ?>
        <main class="admin-layout">
            <aside class="sidebar">
                <div class="admin-mini">
                    <strong><?= e($admin['name']) ?></strong>
                    <span><?= e($admin['email']) ?></span>
                </div>
                <a class="<?= $tab === 'overview' ? 'active' : '' ?>" href="painel.php?tab=overview">Visao geral</a>
                <a class="<?= $tab === 'users' ? 'active' : '' ?>" href="painel.php?tab=users">Usuarios</a>
                <a class="<?= $tab === 'products' ? 'active' : '' ?>" href="painel.php?tab=products">Produtos</a>
                <a class="<?= $tab === 'history' ? 'active' : '' ?>" href="painel.php?tab=history">Historico</a>
            </aside>

            <section class="admin-content">
                <?php if ($tab === 'overview'): ?>
                    <div class="admin-title">
                        <div>
                            <div class="eyebrow">Painel administrativo</div>
                            <h1>Mercadinho em tempo real</h1>
                        </div>
                    </div>
                    <div class="stat-grid">
                        <article><span>Usuarios ativos</span><strong><?= $s['active_users'] ?></strong></article>
                        <article><span>IF Coins</span><strong><?= $s['total_balance'] ?></strong></article>
                        <article><span>Produtos ativos</span><strong><?= $s['active_products'] ?></strong></article>
                        <article><span>Estoque total</span><strong><?= $s['stock'] ?></strong></article>
                    </div>
                    <div class="panel">
                        <h2>Ultimos resgates</h2>
                        <?php render_transactions_table(transactions(12)); ?>
                    </div>
                <?php elseif ($tab === 'users'): ?>
                    <?php $editUser = isset($_GET['edit_user']) ? find_user((int) $_GET['edit_user']) : null; ?>
                    <div class="admin-title">
                        <div>
                            <div class="eyebrow">Usuarios</div>
                            <h1>Codigos e saldos</h1>
                        </div>
                    </div>
                    <div class="split">
                        <section class="panel">
                            <h2><?= $editUser ? 'Editar usuario' : 'Cadastrar usuario' ?></h2>
                            <form method="post" class="form-grid">
                                <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                                <input type="hidden" name="action" value="<?= $editUser ? 'update_user' : 'create_user' ?>">
                                <?php if ($editUser): ?><input type="hidden" name="id" value="<?= (int) $editUser['id'] ?>"><?php endif; ?>
                                <label>Nome<input name="name" required value="<?= e($editUser['name'] ?? '') ?>"></label>
                                <label>Email<input type="email" name="email" required value="<?= e($editUser['email'] ?? '') ?>" placeholder="nome@italianofacil.com"></label>
                                <label>Senha<input type="password" name="password" <?= $editUser ? '' : 'required' ?> placeholder="<?= $editUser ? 'Deixe vazio para manter' : 'Senha inicial' ?>"></label>
                                <label>IF Coins<input type="number" name="balance" min="0" value="<?= (int) ($editUser['balance'] ?? 0) ?>"></label>
                                <label>Perfil
                                    <select name="role">
                                        <option value="user" <?= ($editUser['role'] ?? '') === 'user' ? 'selected' : '' ?>>Usuario</option>
                                        <option value="admin" <?= ($editUser['role'] ?? '') === 'admin' ? 'selected' : '' ?>>Administrador</option>
                                    </select>
                                </label>
                                <?php if ($editUser): ?>
                                    <label class="check"><input type="checkbox" name="active" <?= (int) $editUser['active'] === 1 ? 'checked' : '' ?>> Ativo</label>
                                    <label class="check"><input type="checkbox" name="regenerate_code"> Gerar novo codigo</label>
                                    <div class="code-pill">Codigo atual: <strong><?= e($editUser['code']) ?></strong></div>
                                <?php endif; ?>
                                <button type="submit"><?= $editUser ? 'Salvar usuario' : 'Cadastrar usuario' ?></button>
                                <?php if ($editUser): ?><a class="ghost-button" href="painel.php?tab=users">Novo cadastro</a><?php endif; ?>
                            </form>

                            <?php if ($editUser): ?>
                                <hr>
                                <form method="post" class="form-grid compact-form">
                                    <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                                    <input type="hidden" name="action" value="adjust_credit">
                                    <input type="hidden" name="id" value="<?= (int) $editUser['id'] ?>">
                                    <label>Adicionar ou remover IF Coins<input type="number" name="amount" required placeholder="+5 ou -2"></label>
                                    <label>Motivo<input name="reason" value="Ajuste manual"></label>
                                    <button type="submit">Aplicar ajuste</button>
                                </form>
                            <?php endif; ?>
                        </section>
                        <section class="panel">
                            <h2>Lista de usuarios</h2>
                            <div class="table-wrap">
                                <table>
                                    <thead><tr><th>Nome</th><th>Email</th><th>Codigo</th><th>IF Coins</th><th>Status</th><th></th></tr></thead>
                                    <tbody>
                                    <?php foreach (all_users() as $row): ?>
                                        <tr>
                                            <td data-label="Nome"><?= e($row['name']) ?></td>
                                            <td data-label="Email"><?= e($row['email']) ?></td>
                                            <td data-label="Codigo"><strong><?= e($row['code']) ?></strong></td>
                                            <td data-label="IF Coins"><?= (int) $row['balance'] ?></td>
                                            <td data-label="Status"><?= (int) $row['active'] === 1 ? 'Ativo' : 'Inativo' ?></td>
                                            <td data-label="Acao"><a href="painel.php?tab=users&edit_user=<?= (int) $row['id'] ?>">Editar</a></td>
                                        </tr>
                                    <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </section>
                    </div>
                <?php elseif ($tab === 'products'): ?>
                    <?php $editProduct = isset($_GET['edit_product']) ? find_product((int) $_GET['edit_product']) : null; ?>
                    <div class="admin-title">
                        <div>
                            <div class="eyebrow">Estoque</div>
                            <h1>Produtos do mercadinho</h1>
                        </div>
                    </div>
                    <div class="split">
                        <section class="panel">
                            <h2><?= $editProduct ? 'Editar produto' : 'Adicionar produto' ?></h2>
                            <form method="post" enctype="multipart/form-data" class="form-grid">
                                <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                                <input type="hidden" name="action" value="<?= $editProduct ? 'update_product' : 'create_product' ?>">
                                <?php if ($editProduct): ?><input type="hidden" name="id" value="<?= (int) $editProduct['id'] ?>"><?php endif; ?>
                                <label>Nome<input name="name" required value="<?= e($editProduct['name'] ?? '') ?>"></label>
                                <label>Descricao<input name="description" value="<?= e($editProduct['description'] ?? '') ?>"></label>
                                <label>Estoque<input type="number" name="stock" min="0" value="<?= (int) ($editProduct['stock'] ?? 0) ?>"></label>
                                <label>Custo em IF Coins<input type="number" name="cost" min="1" value="<?= (int) ($editProduct['cost'] ?? 1) ?>"></label>
                                <label>URL da imagem<input name="image_url" value="<?= e($editProduct['image_url'] ?? '') ?>" placeholder="https://..."></label>
                                <label>Ou enviar foto<input type="file" name="image" accept="image/*"></label>
                                <?php if ($editProduct): ?>
                                    <label class="check"><input type="checkbox" name="active" <?= (int) $editProduct['active'] === 1 ? 'checked' : '' ?>> Produto ativo</label>
                                <?php endif; ?>
                                <button type="submit"><?= $editProduct ? 'Salvar produto' : 'Cadastrar produto' ?></button>
                                <?php if ($editProduct): ?><a class="ghost-button" href="painel.php?tab=products">Novo produto</a><?php endif; ?>
                            </form>
                        </section>
                        <section class="panel">
                            <h2>Estoque atual</h2>
                            <div class="table-wrap">
                                <table>
                                    <thead><tr><th>Produto</th><th>Estoque</th><th>Custo</th><th>Status</th><th></th><th></th></tr></thead>
                                    <tbody>
                                    <?php foreach (db()->query('SELECT * FROM products ORDER BY active DESC, stock <= 0, name')->fetchAll() as $row): ?>
                                        <tr>
                                            <td data-label="Produto"><?= e($row['name']) ?></td>
                                            <td data-label="Estoque"><?= (int) $row['stock'] ?></td>
                                            <td data-label="Custo"><?= (int) $row['cost'] ?> IF Coin<?= (int) $row['cost'] > 1 ? 's' : '' ?></td>
                                            <td data-label="Status"><?= (int) $row['active'] === 1 ? 'Ativo' : 'Inativo' ?></td>
                                            <td data-label="Editar"><a href="painel.php?tab=products&edit_product=<?= (int) $row['id'] ?>">Editar</a></td>
                                            <td data-label="Remover">
                                                <?php if ((int) $row['active'] === 1): ?>
                                                    <form method="post" data-confirm="Remover <?= e($row['name']) ?> da vitrine?">
                                                        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                                                        <input type="hidden" name="action" value="remove_product">
                                                        <input type="hidden" name="id" value="<?= (int) $row['id'] ?>">
                                                        <button class="danger-button" type="submit">Remover</button>
                                                    </form>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </section>
                    </div>
                <?php elseif ($tab === 'history'): ?>
                    <div class="admin-title">
                        <div>
                            <div class="eyebrow">Historico</div>
                            <h1>Resgates realizados</h1>
                        </div>
                    </div>
                    <section class="panel">
                        <?php render_transactions_table(transactions(200)); ?>
                    </section>
                <?php endif; ?>
            </section>
        </main>
    <?php else: ?>
        <main class="empty-state">
            <h1>Acesso indisponivel</h1>
            <p>Entre com uma conta valida para continuar.</p>
            <a class="ghost-button" href="index.php">Voltar</a>
        </main>
    <?php endif; ?>
</div>
<script src="assets/app.js?v=20260624-ifcoins-4"></script>
</body>
</html>

<?php
function render_transactions_table(array $rows): void
{
    ?>
    <div class="table-wrap">
        <table>
            <thead><tr><th>Data</th><th>Colaborador</th><th>Codigo</th><th>Produto</th><th>Custo</th></tr></thead>
            <tbody>
            <?php if (!$rows): ?>
                <tr><td colspan="5">Nenhum resgate registrado ainda.</td></tr>
            <?php endif; ?>
            <?php foreach ($rows as $row): ?>
                <tr>
                    <td data-label="Data"><?= e(date('d/m/Y H:i', strtotime($row['created_at']))) ?></td>
                    <td data-label="Colaborador"><?= e($row['user_name']) ?></td>
                    <td data-label="Codigo"><strong><?= e($row['code_used']) ?></strong></td>
                    <td data-label="Produto"><?= e($row['product_name']) ?></td>
                    <td data-label="Custo"><?= (int) $row['cost'] ?> IF Coin<?= (int) $row['cost'] > 1 ? 's' : '' ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php
}
?>
