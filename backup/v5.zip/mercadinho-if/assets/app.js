let soundEnabled = true;
let audioContext = null;

const soundToggle = document.querySelector('#sound-toggle');
const codeInputs = document.querySelectorAll('input[name="code"]');

function audio() {
  if (!soundEnabled) return null;
  const AudioContext = window.AudioContext || window.webkitAudioContext;
  if (!AudioContext) return null;
  try {
    audioContext = audioContext || new AudioContext();
    return audioContext;
  } catch (error) {
    return null;
  }
}

function tone(frequency = 520, duration = 0.08, type = 'sine', volume = 0.035) {
  try {
    const ctx = audio();
    if (!ctx) return;

    const oscillator = ctx.createOscillator();
    const gain = ctx.createGain();
    oscillator.type = type;
    oscillator.frequency.value = frequency;
    gain.gain.value = volume;
    oscillator.connect(gain);
    gain.connect(ctx.destination);
    oscillator.start();
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + duration);
    oscillator.stop(ctx.currentTime + duration);
  } catch (error) {
    return;
  }
}

function sound(kind) {
  if (kind === 'cash') {
    tone(980, 0.045, 'triangle', 0.04);
    window.setTimeout(() => tone(1220, 0.05, 'triangle', 0.035), 65);
    window.setTimeout(() => tone(760, 0.055, 'square', 0.018), 120);
    window.setTimeout(() => tone(1460, 0.07, 'triangle', 0.03), 185);
    return;
  }
  if (kind === 'success') {
    tone(620, 0.08, 'triangle', 0.035);
    window.setTimeout(() => tone(860, 0.10, 'triangle', 0.03), 90);
    return;
  }
  if (kind === 'error') {
    tone(180, 0.12, 'sawtooth', 0.025);
    return;
  }
  if (kind === 'submit') {
    tone(480, 0.07, 'sine', 0.025);
    return;
  }
  tone(360, 0.045, 'sine', 0.018);
}

function sparkle(x, y) {
  for (let i = 0; i < 9; i += 1) {
    const dot = document.createElement('span');
    const angle = (Math.PI * 2 * i) / 9;
    const distance = 32 + Math.random() * 26;
    dot.className = 'sparkle';
    dot.style.left = `${x}px`;
    dot.style.top = `${y}px`;
    dot.style.setProperty('--x', `${Math.cos(angle) * distance}px`);
    dot.style.setProperty('--y', `${Math.sin(angle) * distance}px`);
    document.body.appendChild(dot);
    window.setTimeout(() => dot.remove(), 800);
  }
}

codeInputs.forEach((input) => {
  input.addEventListener('input', () => {
    input.value = input.value
      .toUpperCase()
      .replace(/[^A-Z0-9]/g, '')
      .slice(0, 5);

    if (input.value.length === 5) {
      sound('success');
    }
  });
});

document.querySelectorAll('button, .ghost-button, .product-card').forEach((element) => {
  element.addEventListener('pointerdown', (event) => {
    sound('tap');
    if (event.clientX && event.clientY) {
      sparkle(event.clientX, event.clientY);
    }
  });
});

document.querySelectorAll('form[data-confirm]').forEach((form) => {
  form.addEventListener('submit', (event) => {
    const message = form.getAttribute('data-confirm') || 'Confirmar acao?';
    if (!window.confirm(message)) {
      sound('error');
      event.preventDefault();
      return;
    }
    sound('submit');
  });
});

document.querySelectorAll('form:not([data-confirm])').forEach((form) => {
  form.addEventListener('submit', () => sound('submit'));
});

if (soundToggle) {
  soundToggle.addEventListener('click', () => {
    soundEnabled = !soundEnabled;
    soundToggle.setAttribute('aria-pressed', soundEnabled ? 'true' : 'false');
    soundToggle.textContent = soundEnabled ? 'Som ligado' : 'Som desligado';
    if (soundEnabled) sound('success');
  });
}

if (document.body.dataset.picked === '1') {
  document.body.classList.add('picked');
  window.setTimeout(() => {
    sound('cash');
    const card = document.querySelector('.balance-card');
    if (card) {
      const rect = card.getBoundingClientRect();
      sparkle(rect.left + rect.width / 2, rect.top + rect.height / 2);
    }
  }, 250);
}

if (document.body.dataset.flash === 'error') {
  window.setTimeout(() => sound('error'), 250);
}
