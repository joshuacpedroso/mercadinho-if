<?php
return [
    'enabled' => true,
    'host' => 'smtp.titan.email',
    'port' => 465,
    'encryption' => 'ssl',
    'username' => 'ifcoins@italianofacil.com',
    'password' => 'Italiano@123',
    'from_email' => 'ifcoins@italianofacil.com',
    'from_name' => 'IF Coins',
    'timeout' => 20,
];
