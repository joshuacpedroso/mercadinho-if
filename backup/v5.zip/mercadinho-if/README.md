# Mercadinho IF

Sistema interno do mercadinho da empresa. As moedas usadas para resgatar produtos se chamam IF Coins.

## Telas principais

- Mercadinho: `index.php`
- Painel administrativo: `painel.php`

## Primeiro acesso ao painel

- URL local: `http://localhost:8000/painel.php`
- Email: `admin@italianofacil.com`
- Senha: `admin123`

Depois do primeiro acesso, entre no painel administrativo e troque a senha do administrador.

## Como rodar localmente

```bash
cd mercadinho-if
php -S localhost:8000
```

## Como usar

1. O administrador acessa `painel.php` e cadastra usuarios com email corporativo, senha e quantidade de IF Coins.
2. Cada usuario recebe um codigo aleatorio de 5 caracteres.
3. O colaborador digita o codigo em `index.php`.
4. O sistema mostra os IF Coins disponiveis e os produtos liberados.
5. Ao clicar em `Resgatar item`, o sistema desconta os IF Coins do colaborador e baixa uma unidade do estoque.

## Recursos

- Login com email corporativo.
- Cadastro e edicao de usuarios.
- Codigo unico de 5 caracteres por colaborador.
- Controle de IF Coins por pessoa.
- Email automatico quando IF Coins sao adicionados.
- Cadastro, edicao e inativacao de produtos.
- Upload ou URL de imagem do produto.
- Controle de estoque.
- Historico de retiradas.
- Banco SQLite criado automaticamente em `data/mercadinho.sqlite`.

## Observacao de hospedagem

O servidor precisa ter PHP com extensao SQLite habilitada. A pasta `data` deve ter permissao de escrita para o banco, e a pasta `uploads` deve ter permissao de escrita para salvar fotos dos produtos.

## Email

O envio usa SMTP Titan em `data/mail_config.php`. O arquivo fica dentro da pasta protegida `data`.
